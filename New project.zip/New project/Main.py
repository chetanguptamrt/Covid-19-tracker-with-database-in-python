import requests
from bs4 import BeautifulSoup
from tkinter import*
from tkinter.ttk import Treeview
from tkinter.messagebox import showerror,showinfo
import mysql.connector
from threading import Thread
from datetime import datetime

class Main:

    def __init__(self):
        self.root=Tk()
        self.root.title("COVID 19 TRACKER")
        self.root.geometry("1100x650+10+10")
        self.root.minsize(1100,650)
        self.root.iconbitmap("coronavirus_QT2_icon.ico")
        Label(text="Welcome to Covid 19 Tracker Application",fg="red",bg='black',font='comicsansms 20 bold',bd=18,relief=SUNKEN).pack(fill=X)
        #-------------frame-------------------
        self.main_frame=Frame(self.root)
        self.main_frame.pack()
        #------------variable------------------
        self.textfield_var=StringVar()
        self.covidData=StringVar()
        self.covidData.set("please wait...")
        self.frame1()
        self.mysql_connect()
        Thread(target=self.reload).start()
        self.root.mainloop()

    # for mysql connector
    def mysql_connect(self):
        self.mydb = mysql.connector.connect(host="localhost",user="root",password="tiwariaman",port=3306,database="covid_19_tracker")
        if not self.mydb.is_connected():
            showinfo("MySQL Error","Database is not connected")
            self.root.destory()

    #for main window
    def frame1(self):
        self.banner=PhotoImage(file="coronavirus.png")
        Label(self.main_frame,image=self.banner).pack(pady=25)
        Label(self.main_frame,text="Enter the country name here",font="verdana 14 bold").pack(pady=5)
        Entry(self.main_frame,textvariable=self.textfield_var,font="verdana 22",width=24,relief=RAISED,borderwidth=2,fg='#000000').pack()
        Label(self.main_frame,textvariable=self.covidData,height=3,font=("verdana",18)).pack()
        self.btn_frame=Frame(self.main_frame)
        self.btn_frame.pack(pady=(0,10))
        Button(self.btn_frame,text="Get Data",font="comicsansms 18 bold",width=8,relief=RIDGE,borderwidth=3,fg='#000000',command=self.get_country_data).pack(side=LEFT)
        Button(self.btn_frame,text="Global Data",font="comicsansms 18 bold",width=12,relief="ridge",borderwidth=3,fg='#000000',command=self.reload).pack(side=LEFT,padx=20)
        Button(self.btn_frame,text='Exit',font="comicsansms 18 bold",width=8,relief="ridge",borderwidth=3,fg='#000000',command=self.root.destroy).pack(side=LEFT)
        Button(self.main_frame,text='History',font="comicsansms 16 bold",width=8,relief="ridge",borderwidth=3,fg='#000000',command=self.frame2).pack()

    #for history
    def frame2(self):
        self.main_frame.destroy()
        self.main_frame=Frame(self.root)
        self.main_frame.pack()
        Label(self.main_frame,text="Search History",font="verdana 16 bold").pack(pady=25)
        self.treeFrame = Frame(self.main_frame)
        self.treeFrame.pack()
        self.verscrlbar = Scrollbar(self.treeFrame,orient ="vertical") 
        self.verscrlbar.pack(side ='right', fill ='y')
        self.treev = Treeview(self.treeFrame, selectmode ='browse',height=18)  
        self.treev.pack()
        self.treev.configure(xscrollcommand = self.verscrlbar.set) 
        self.verscrlbar.configure(command = self.treev.yview)
        self.treev["columns"] = ("1", "2", "3","4","5")
        self.treev['show'] = 'headings'
        self.treev.column("1", width = 150, anchor ='c') 
        self.treev.column("2", width = 150, anchor ='c') 
        self.treev.column("3", width = 150, anchor ='c') 
        self.treev.column("4", width = 150, anchor ='c') 
        self.treev.column("5", width = 150, anchor ='c') 
        self.treev.heading("1", text ="Country Name") 
        self.treev.heading("2", text ="Time") 
        self.treev.heading("3", text ="Total Case")
        self.treev.heading("4", text ="Recoverd")
        self.treev.heading("5", text ="Deaths")
        self.btn_frame=Frame(self.main_frame)
        self.btn_frame.pack()
        Button(self.btn_frame,text='Back',font="comicsansms 14 bold",width=7,relief="ridge",borderwidth=3,fg='#000000',command=self.frameDes).pack(pady=20,padx=(0,50),side=LEFT)
        Button(self.btn_frame,text='Clear',font="comicsansms 14 bold",width=7,relief="ridge",borderwidth=3,fg='#000000',command=self.clearTable).pack(pady=20,side=LEFT)
        self.getDataInTable()

    #for destory frame and back to frame1
    def frameDes(self):
        self.main_frame.destroy()
        self.main_frame=Frame(self.root)
        self.main_frame.pack()
        self.frame1()

    def get_html_data(self,url):
        return requests.get(url)

    #get country data and save in database
    def get_country_data(self):
        if (self.textfield_var.get().strip()!=""):
            try:
                name=self.textfield_var.get().strip()
                url='https://www.worldometers.info/coronavirus/country/' + name
                html_data=self.get_html_data(url)
                bs=BeautifulSoup(html_data.text,'html.parser')
                info_div=bs.find("div",class_="content-inner").findAll("div",id="maincounter-wrap")
                all_data=""
                temp=[]
                for block in info_div:
                    text=block.find("h1",class_=None).get_text()
                    count=block.find("span",class_=None).get_text()
                    all_data=all_data + text + " " + count + "\n"
                    temp.append(count)
                self.covidData.set(all_data.strip())
                self.textfield_var.set("")
            except:
                showerror("Error","Data not found\nOr Network problem")
            try:
                #insert into databases
                myc = self.mydb.cursor(prepared=True)
                sql = "insert into history values (?,?,?,?,?)"
                myc.execute(sql,(name,str(datetime.now().strftime("%d/%m/%Y %H:%M:%S")),temp[0],temp[1],temp[2]))
                self.mydb.commit()
            except:
                self.mydb.rollback()

    #get global data
    def reload(self):
        try:
            url='https://www.worldometers.info/coronavirus/'
            html_data=self.get_html_data(url)
            bs=BeautifulSoup(html_data.text,'html.parser')
            info_div=bs.find("div",class_="content-inner").findAll("div",id="maincounter-wrap")
            all_data=""
            for block in info_div:
                text=block.find("h1",class_=None).get_text()  
                count=block.find("span",class_=None).get_text()
                all_data=all_data + text + " " + count + "\n"
            self.covidData.set(all_data.strip())
        except:
            showerror("Error","Data not found\nOr Network problem")

    #update treeview(table in tkinter)
    def getDataInTable(self):
        try:
            myc = self.mydb.cursor()
            myc.execute("SELECT * FROM history")
            rows=myc.fetchall()
            self.treev.delete(*self.treev.get_children())
            for i in rows:
                self.treev.insert('', '0',values=i)
        except:
            pass
    
    #clear all data from database then update treeview
    def clearTable(self):
        try:
            #insert into databases
            myc = self.mydb.cursor()
            myc.execute("delete from history")
            self.mydb.commit()
            self.getDataInTable()  
        except:
            self.mydb.rollback()
            showerror("Error","Database Error")

if __name__=="__main__":
    Main()